			<footer class="footer">
        <p>&copy; 2016 JobLister, Inc.</p>
      </footer>

    </div> <!-- /container -->
		</body>
</html>